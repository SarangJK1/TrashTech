function goToDashboard(event) {
  event.preventDefault(); 
  window.location.href = "dashboard.html";
}

function goToBins() {
  window.location.href = "bins.html";
}

function goToLogin() {
  window.location.href = "login.html";
}
function goToCamera() {
    window.location.href = "camera.html";
}
function goToAdmin() {
    window.location.href = "admin.html";
}

function viewUsers() {
    alert("User list feature coming soon!");
}

function viewBins() {
    alert("Bin management coming soon!");
}

function viewPayments() {
    alert("Payment dashboard coming soon!");
}
function goToPro() {
    window.location.href = "pro.html";
}

// Simulate a payment (fake purchase)
function buyPro() {
    localStorage.setItem("isPro", "true");
    alert("🎉 You are now a Pro Member!");
    window.location.href = "dashboard.html";
}
// After successful login:
localStorage.setItem("username", usernameInput.value);
localStorage.setItem("isPro", "false"); // default when user signs in
function requirePro() {
    const isPro = localStorage.getItem("isPro");
    if (isPro !== "true") {
        document.getElementById("proWarning").style.display = "block";
        setTimeout(() => {
            document.getElementById("proWarning").style.display = "none";
        }, 2000);
        return false;
    }
    return true;
}

function openCameraScan() {
    if (!requirePro()) return;
    alert("📸 Opening AI Camera Scanner... (feature coming)");
}

function refreshData() {
    if (!requirePro()) return;
    alert("🔄 Refreshing data instantly...");
}

function openAnalytics() {
    if (!requirePro()) return;
    alert("📊 Opening advanced analytics...");
}


