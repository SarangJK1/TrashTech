package com.smart.waste;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
